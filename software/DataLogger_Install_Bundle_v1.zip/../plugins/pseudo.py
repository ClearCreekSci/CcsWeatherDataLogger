# Copyright (c) 2025 Clear Creek Scientific
#
# Based on adafruit's circuit python-bme280 code (pip install adafruit-circuitpython-bme280)
#
# The MIT License (MIT)
#
# Copyright (c) 2017 ladyada for Adafruit Industries
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
#         

import random

CCS_AIR_TEMPERATURE_UUID            = 'a0ce0210-3bbf-11ee-89eb-00e04c400cc5'
CCS_HUMIDITY_UUID                   = 'a0ce0211-3bbf-11ee-89eb-00e04c400cc5'
CCS_AIR_PRESSURE_UUID               = 'a0ce0212-3bbf-11ee-89eb-00e04c400cc5'

class Pseudo(object):

    def __init__(self):
        pass

  
    def get_value(self,base,big_mult,small_mult):
        rv = base 
        delta = random.random() * big_mult
        op = random.randint(0,1)
        if op == 1:
            rv += delta
        else:
            rv -= delta
        delta = random.random() * small_mult 
        op = random.randint(0,1)
        if op == 1:
            rv += delta
        else:
            rv -= delta
        return rv


    # The following functions implement the interface for a Sensor module
    def get_label(self):
        return 'pseudo'

    def get_description(self):
        return 'temperature, humidity, and air pressure'

    def get_uuids(self):
        return (CCS_AIR_TEMPERATURE_UUID,CCS_HUMIDITY_UUID,CCS_AIR_PRESSURE_UUID)


    # Returns a tuple of tuples, each containing the uuid of the value 
    # and the value itself expressed as a string representing a floating point number
    def get_current_values(self):
        tc = self.get_value(25.0,5.0,1.0)
        temperature = (CCS_AIR_TEMPERATURE_UUID,'{:.{}f}'.format(tc,2))
        rh = self.get_value(55.0,5.0,1.0)
        humidity = (CCS_HUMIDITY_UUID,'{:.{}f}'.format(rh,2))
        ap = self.get_value(750,20.0,1.0)
        pressure = (CCS_AIR_PRESSURE_UUID,'{:.{}f}'.format(ap,2))
        return (temperature,humidity,pressure)


def load():
    return Pseudo()


